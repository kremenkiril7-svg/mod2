package com.visuals;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.Arrays;

public class Config {
    public static int mobSound = 0, playerSound = 0;   // 0 Нет, 1 Луч света, 2 Падение человека, 3 Святой дух
    public static int mobAnim = 0, playerAnim = 0;     // 0 Нет, 1 Красная молния, 2 Золотой столб, 3 Огненный взрыв
    public static int hitSound = 0, hitVol = 1;        // звук удара 0..6, громкость 0..3
    public static int keyMenu = 344;                   // Right Shift
    public static final int[] keys = new int[16];      // клавиши функций, -1 = не назначена
    public static float radius = 3.5f;                 // радиус удара
    public static int cps = 10;                        // скорость ударов в секунду
    public static boolean auraCd = true;               // килаура с перезарядкой 1.9
    public static int pickupRadius = 5;                // радиус авто-подбора
    public static boolean island = true;               // анимация плеера (остров)

    // песни / текст
    public static boolean lyrics = true;
    public static int lyricsPos = 0;                   // 0 снизу, 1 сверху, 2 по центру
    public static float lyricsSize = 1.3f;

    // приколно: инфо-панель
    public static boolean infoArmor = true, infoInv = true, infoHotbar = true, infoDura = true, infoFood = true, infoSlots = true;
    public static int infoCorner = 0;                  // 0 прав-верх, 1 лев-верх, 2 прав-низ, 3 лев-низ
    public static float infoScale = 1.0f;
    // приколно: FPS
    public static int fpsMode = 0;                     // 0 остров, 1 строка, 2 текст, 3 выкл
    public static int fpsPos = 0;                      // 0 верх-центр, 1 верх-лево, 2 верх-право, 3 низ-лево, 4 низ-право
    // приколно: прыжок
    public static int jumpAnim = 0, jumpColor = 1;     // 0 нет, 1 корона, 2 кольцо, 3 спираль, 4 искры
    public static boolean jumpLand = false;
    public static float jumpSize = 1.0f;
    // оптимизация
    public static int optLevel = 0;
    public static boolean optSaved = false;
    public static int oView = 12, oSim = 12, oBlend = 2, oGfx = 1, oCloud = 2, oPart = 0, oFps = 120;
    public static double oEnt = 1.0;
    public static boolean oShadow = true, oVsync = true;
    // одежда
    public static int hatType = 0, hatColor = 0, wingType = 0, wingColor = 0;
    public static float hatScale = 1.0f, wingScale = 1.0f;
    public static boolean wingFlap = true;

    static { Arrays.fill(keys, -1); }
    static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("visuals_mod.json");

    static int i(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }
    static boolean b(JsonObject o, String k, boolean d) { return o.has(k) ? o.get(k).getAsBoolean() : d; }
    static float f(JsonObject o, String k, float d) { return o.has(k) ? o.get(k).getAsFloat() : d; }
    static double dd(JsonObject o, String k, double d) { return o.has(k) ? o.get(k).getAsDouble() : d; }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            JsonObject o = JsonParser.parseString(Files.readString(PATH)).getAsJsonObject();
            mobSound = i(o, "mobSound", 0);
            playerSound = i(o, "playerSound", 0);
            mobAnim = i(o, "mobAnim", 0);
            playerAnim = i(o, "playerAnim", 0);
            hitSound = i(o, "hitSound", 0);
            hitVol = i(o, "hitVol", 1);
            keyMenu = i(o, "keyMenu", 344);
            radius = f(o, "radius", 3.5f);
            cps = i(o, "cps", 10);
            auraCd = b(o, "auraCd", true);
            pickupRadius = i(o, "pickupRadius", 5);
            island = b(o, "island", true);
            lyrics = b(o, "lyrics", true);
            lyricsPos = i(o, "lyricsPos", 0);
            lyricsSize = f(o, "lyricsSize", 1.3f);
            infoArmor = b(o, "infoArmor", true);
            infoInv = b(o, "infoInv", true);
            infoHotbar = b(o, "infoHotbar", true);
            infoDura = b(o, "infoDura", true);
            infoFood = b(o, "infoFood", true);
            infoSlots = b(o, "infoSlots", true);
            infoCorner = i(o, "infoCorner", 0);
            infoScale = f(o, "infoScale", 1.0f);
            fpsMode = i(o, "fpsMode", 0);
            fpsPos = i(o, "fpsPos", 0);
            jumpAnim = i(o, "jumpAnim", 0);
            jumpColor = i(o, "jumpColor", 1);
            jumpLand = b(o, "jumpLand", false);
            jumpSize = f(o, "jumpSize", 1.0f);
            optLevel = i(o, "optLevel", 0);
            optSaved = b(o, "optSaved", false);
            oView = i(o, "oView", 12); oSim = i(o, "oSim", 12); oBlend = i(o, "oBlend", 2);
            oGfx = i(o, "oGfx", 1); oCloud = i(o, "oCloud", 2); oPart = i(o, "oPart", 0); oFps = i(o, "oFps", 120);
            oEnt = dd(o, "oEnt", 1.0);
            oShadow = b(o, "oShadow", true); oVsync = b(o, "oVsync", true);
            hatType = i(o, "hatType", 0); hatColor = i(o, "hatColor", 0);
            wingType = i(o, "wingType", 0); wingColor = i(o, "wingColor", 0);
            hatScale = f(o, "hatScale", 1.0f); wingScale = f(o, "wingScale", 1.0f);
            wingFlap = b(o, "wingFlap", true);
            if (o.has("keys")) {
                JsonArray a = o.getAsJsonArray("keys");
                for (int n = 0; n < keys.length && n < a.size(); n++) keys[n] = a.get(n).getAsInt();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("mobSound", mobSound);
            o.addProperty("playerSound", playerSound);
            o.addProperty("mobAnim", mobAnim);
            o.addProperty("playerAnim", playerAnim);
            o.addProperty("hitSound", hitSound);
            o.addProperty("hitVol", hitVol);
            o.addProperty("keyMenu", keyMenu);
            o.addProperty("radius", radius);
            o.addProperty("cps", cps);
            o.addProperty("auraCd", auraCd);
            o.addProperty("pickupRadius", pickupRadius);
            o.addProperty("island", island);
            o.addProperty("lyrics", lyrics);
            o.addProperty("lyricsPos", lyricsPos);
            o.addProperty("lyricsSize", lyricsSize);
            o.addProperty("infoArmor", infoArmor);
            o.addProperty("infoInv", infoInv);
            o.addProperty("infoHotbar", infoHotbar);
            o.addProperty("infoDura", infoDura);
            o.addProperty("infoFood", infoFood);
            o.addProperty("infoSlots", infoSlots);
            o.addProperty("infoCorner", infoCorner);
            o.addProperty("infoScale", infoScale);
            o.addProperty("fpsMode", fpsMode);
            o.addProperty("fpsPos", fpsPos);
            o.addProperty("jumpAnim", jumpAnim);
            o.addProperty("jumpColor", jumpColor);
            o.addProperty("jumpLand", jumpLand);
            o.addProperty("jumpSize", jumpSize);
            o.addProperty("optLevel", optLevel);
            o.addProperty("optSaved", optSaved);
            o.addProperty("oView", oView); o.addProperty("oSim", oSim); o.addProperty("oBlend", oBlend);
            o.addProperty("oGfx", oGfx); o.addProperty("oCloud", oCloud); o.addProperty("oPart", oPart); o.addProperty("oFps", oFps);
            o.addProperty("oEnt", oEnt);
            o.addProperty("oShadow", oShadow); o.addProperty("oVsync", oVsync);
            o.addProperty("hatType", hatType);
            o.addProperty("hatColor", hatColor);
            o.addProperty("wingType", wingType);
            o.addProperty("wingColor", wingColor);
            o.addProperty("hatScale", hatScale);
            o.addProperty("wingScale", wingScale);
            o.addProperty("wingFlap", wingFlap);
            JsonArray a = new JsonArray();
            for (int k : keys) a.add(k);
            o.add("keys", a);
            Files.writeString(PATH, o.toString());
        } catch (Exception ignored) {}
    }
}
