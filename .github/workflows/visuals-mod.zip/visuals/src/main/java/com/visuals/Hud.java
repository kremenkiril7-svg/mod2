package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

// Показ FPS: остров / строка (мод | fps | tps | пинг) / просто текст / выкл
public class Hud {
    public static final String[] FPS_MODES = {"Остров", "Строка", "Текст", "Выкл"};
    public static final String[] FPS_POS = {"Сверху по центру", "Сверху слева", "Сверху справа", "Снизу слева", "Снизу справа"};
    public static final String[] CORNERS = {"Пр.верх", "Лев.верх", "Пр.низ", "Лев.низ"};

    static int ticks = 0;
    static long lastMs = System.currentTimeMillis();
    public static float tps = 20f;

    // считаем тики клиента за реальную секунду
    public static void tick() {
        ticks++;
        long now = System.currentTimeMillis();
        if (now - lastMs >= 1000) {
            tps = Math.min(20f, ticks * 1000f / (now - lastMs));
            ticks = 0;
            lastMs = now;
        }
    }

    public static String watermark(MinecraftClient mc) {
        int ping = 0;
        try {
            if (mc.getNetworkHandler() != null && mc.player != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
        } catch (Throwable ignored) {}
        return "Visuals | " + mc.getCurrentFps() + " fps | " + String.format("%.1f", tps) + " tps | " + ping + " ms";
    }

    // режим «Текст»: без фона, в выбранном углу
    public static void plain(DrawContext c, MinecraftClient mc, int sw, int sh) {
        if (Config.fpsMode != 2) return;
        String s = mc.getCurrentFps() + " FPS";
        int w = mc.textRenderer.getWidth(s);
        int pos = Config.fpsPos;
        int x = pos == 1 || pos == 3 ? 4 : (pos == 2 || pos == 4 ? sw - w - 4 : (sw - w) / 2);
        int y = pos >= 3 ? sh - 14 : 4;
        c.drawTextWithShadow(mc.textRenderer, s, x, y, 0xFFFFFFFF);
    }
}
