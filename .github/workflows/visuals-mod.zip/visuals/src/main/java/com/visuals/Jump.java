package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import java.util.Random;

// Анимация прыжка (кольцо/корона на земле, как на видео) из частиц
public class Jump {
    public static final String[] STYLES = {"Нет", "Корона", "Кольцо", "Спираль", "Искры"};
    public static final String[] COLOR_NAMES = {"Белый", "Бирюза", "Красный", "Золото", "Фиолет", "Зелёный", "Радуга"};
    public static final int[] COLORS = {0xFFFFFF, 0x40FFE0, 0xFF3030, 0xFFD040, 0xB050FF, 0x50FF60, -1};
    static final Random R = new Random();
    static boolean wasGround = true;
    static double prevVy = 0;

    static int rgb(int idx, int t) {
        int c = COLORS[Math.max(0, Math.min(COLORS.length - 1, idx))];
        if (c >= 0) return c;
        return hsv(((t * 9 + System.currentTimeMillis() / 8) % 360) / 360f);
    }

    public static int hsv(float h) {
        float r = 0, g = 0, b = 0;
        int i = (int) (h * 6) % 6;
        float f = h * 6 - (int) (h * 6);
        float q = 1 - f;
        switch (i) {
            case 0 -> { r = 1; g = f; }
            case 1 -> { r = q; g = 1; }
            case 2 -> { g = 1; b = f; }
            case 3 -> { g = q; b = 1; }
            case 4 -> { r = f; b = 1; }
            default -> { r = 1; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        boolean g = p.isOnGround();
        double vy = p.getVelocity().y;
        if (Config.jumpAnim > 0 && !p.isTouchingWater() && !p.getAbilities().flying) {
            if (wasGround && !g && vy > 0.1) play(Config.jumpAnim, p.getPos());
            else if (Config.jumpLand && !wasGround && g && prevVy < -0.45) play(Config.jumpAnim, p.getPos());
        }
        wasGround = g;
        prevVy = vy;
    }

    public static void play(int type, Vec3d p) {
        final float sz = Config.jumpSize;
        final int col = Config.jumpColor;
        final int step = Config.optLevel >= 2 ? 3 : 2;      // при оптимизации частиц меньше
        switch (type) {
            case 1 -> Anims.TASKS.add(new Anims.Task(16, (w, t) -> {
                if (t % step != 0) return;
                double k = 1 - Math.pow(1 - t / 15.0, 2);
                double r = (0.45 + 0.85 * k) * sz;
                DustParticleEffect d = new DustParticleEffect(rgb(col, t), 0.7f * Math.min(1.3f, sz));
                DustParticleEffect white = new DustParticleEffect(0xFFFFFF, 0.6f);
                int n = 14;
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n + t * 0.05;
                    double cx = Math.cos(a) * r, cz = Math.sin(a) * r;
                    w.addParticle(white, p.x + cx, p.y + 0.04, p.z + cz, 0, 0, 0);
                    w.addParticle(d, p.x + cx, p.y + 0.16, p.z + cz, 0, 0, 0);
                    if (i % 2 == 0) {                          // зубцы короны
                        w.addParticle(white, p.x + cx, p.y + 0.30 * sz, p.z + cz, 0, 0, 0);
                        w.addParticle(d, p.x + cx, p.y + 0.44 * sz, p.z + cz, 0, 0, 0);
                    }
                }
                if (t % 4 == 0)
                    for (int i = 0; i < 4; i++)
                        w.addParticle(ParticleTypes.END_ROD, p.x + (R.nextDouble() - .5) * 2 * r, p.y + 0.1,
                                p.z + (R.nextDouble() - .5) * 2 * r, 0, 0.03, 0);
            }));
            case 2 -> Anims.TASKS.add(new Anims.Task(12, (w, t) -> {
                double r = (0.3 + t * 0.16) * sz;
                DustParticleEffect d = new DustParticleEffect(rgb(col, t), 1.0f * Math.min(1.3f, sz));
                int n = 22;
                for (int i = 0; i < n; i++) {
                    double a = i * Math.PI * 2 / n;
                    w.addParticle(d, p.x + Math.cos(a) * r, p.y + 0.06, p.z + Math.sin(a) * r, 0, 0, 0);
                }
            }));
            case 3 -> Anims.TASKS.add(new Anims.Task(16, (w, t) -> {
                DustParticleEffect d = new DustParticleEffect(rgb(col, t), 0.8f);
                for (int s = 0; s < 2; s++) {
                    double a = t * 0.7 + s * Math.PI;
                    double y = t * 0.13 * sz;
                    w.addParticle(d, p.x + Math.cos(a) * 0.75 * sz, p.y + y, p.z + Math.sin(a) * 0.75 * sz, 0, 0, 0);
                    w.addParticle(ParticleTypes.END_ROD, p.x + Math.cos(a) * 0.75 * sz, p.y + y, p.z + Math.sin(a) * 0.75 * sz, 0, 0, 0);
                }
            }));
            case 4 -> Anims.TASKS.add(new Anims.Task(2, (w, t) -> {
                if (t > 0) return;
                DustParticleEffect d = new DustParticleEffect(rgb(col, 0), 0.9f);
                for (int i = 0; i < 20; i++) {
                    double a = R.nextDouble() * Math.PI * 2, s = (0.05 + R.nextDouble() * 0.12) * sz;
                    w.addParticle(ParticleTypes.END_ROD, p.x, p.y + 0.1, p.z, Math.cos(a) * s, 0.05 + R.nextDouble() * 0.12, Math.sin(a) * s);
                    if (i % 2 == 0) w.addParticle(d, p.x + Math.cos(a) * 0.5 * sz, p.y + 0.1 + R.nextDouble() * 0.4, p.z + Math.sin(a) * 0.5 * sz, 0, 0, 0);
                }
            }));
            default -> {}
        }
    }
}
