package com.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;
import java.util.Objects;

// Оптимизация FPS: набор настроек игры, которые сильнее всего грузят слабый ПК.
// Оригинальные настройки запоминаются и возвращаются при выключении.
public class Opt {
    public static final String[] NAMES = {"Выкл", "Лёгкая", "Сильная", "Макс"};

    static <T> void set(SimpleOption<T> o, T v) {
        if (!Objects.equals(o.getValue(), v)) o.setValue(v);
    }

    static void save(GameOptions o) {
        Config.oView = o.getViewDistance().getValue();
        Config.oSim = o.getSimulationDistance().getValue();
        Config.oBlend = o.getBiomeBlendRadius().getValue();
        Config.oEnt = o.getEntityDistanceScaling().getValue();
        Config.oGfx = o.getGraphicsMode().getValue().ordinal();
        Config.oCloud = o.getCloudRenderMode().getValue().ordinal();
        Config.oPart = o.getParticles().getValue().ordinal();
        Config.oFps = o.getMaxFps().getValue();
        Config.oShadow = o.getEntityShadows().getValue();
        Config.oVsync = o.getEnableVsync().getValue();
        Config.optSaved = true;
    }

    public static void apply(MinecraftClient mc, int level) {
        GameOptions o = mc.options;
        if (level > 0 && !Config.optSaved) save(o);
        if (level <= 0) {
            if (Config.optSaved) {
                set(o.getGraphicsMode(), GraphicsMode.values()[Math.min(Config.oGfx, GraphicsMode.values().length - 1)]);
                set(o.getCloudRenderMode(), CloudRenderMode.values()[Math.min(Config.oCloud, CloudRenderMode.values().length - 1)]);
                set(o.getParticles(), ParticlesMode.values()[Math.min(Config.oPart, ParticlesMode.values().length - 1)]);
                set(o.getEntityShadows(), Config.oShadow);
                set(o.getEnableVsync(), Config.oVsync);
                set(o.getMaxFps(), Config.oFps);
                set(o.getBiomeBlendRadius(), Config.oBlend);
                set(o.getEntityDistanceScaling(), Config.oEnt);
                set(o.getSimulationDistance(), Config.oSim);
                set(o.getViewDistance(), Config.oView);
                Config.optSaved = false;
            }
        } else {
            set(o.getGraphicsMode(), GraphicsMode.FAST);
            set(o.getCloudRenderMode(), CloudRenderMode.OFF);
            set(o.getEntityShadows(), false);
            set(o.getEnableVsync(), false);
            set(o.getMaxFps(), 260);
            int blend = level == 1 ? Math.min(Config.oBlend, 2) : (level == 2 ? Math.min(Config.oBlend, 1) : 0);
            double ent = level == 1 ? Math.min(Config.oEnt, 0.8) : (level == 2 ? Math.min(Config.oEnt, 0.55) : Math.min(Config.oEnt, 0.35));
            set(o.getBiomeBlendRadius(), blend);
            set(o.getEntityDistanceScaling(), ent);
            if (level >= 2) {
                set(o.getSimulationDistance(), Math.min(Config.oSim, level == 2 ? 6 : 5));
                set(o.getViewDistance(), Math.min(Config.oView, level == 2 ? 10 : 6));
            } else {
                set(o.getSimulationDistance(), Config.oSim);
                set(o.getViewDistance(), Config.oView);
            }
            set(o.getParticles(), level >= 3 ? ParticlesMode.DECREASED : ParticlesMode.values()[Math.min(Config.oPart, ParticlesMode.values().length - 1)]);
        }
        Config.optLevel = level;
        Config.save();
        o.write();
    }
}
