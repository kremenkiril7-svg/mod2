package com.visuals;

import net.minecraft.client.gui.DrawContext;

// Красный интерфейс: панель с диагональными полосами и «слоты» со скошенными краями
public class Ui {
    public static void panel(DrawContext c, int x, int y, int w, int h) {
        c.fillGradient(x, y, x + w, y + h, 0xFFC41414, 0xFF6E0000);
        for (int yy = 0; yy < h; yy += 2) {
            int off = ((h - yy) % 44 + 44) % 44;
            for (int k = -1; k * 44 < w + 44; k++) {
                int xs = x + k * 44 + off, xe = xs + 12;
                int a = Math.max(xs, x), b = Math.min(xe, x + w);
                if (b > a) c.fill(a, y + yy, b, Math.min(y + yy + 2, y + h), 0x2EFFFFFF);
            }
        }
        c.drawBorder(x, y, w, h, 0xFF140000);
        c.drawBorder(x + 1, y + 1, w - 2, h - 2, 0xFFFF4A4A);
    }

    public static void slot(DrawContext c, int x, int y, int w, int h, boolean active) {
        c.fill(x, y, x + w, y + h, active ? 0xFF9A0000 : 0xFF4E0000);
        c.fill(x, y, x + w, y + 1, 0xFF1E0000);
        c.fill(x, y, x + 1, y + h, 0xFF1E0000);
        c.fill(x, y + h - 1, x + w, y + h, 0xFFFF7A7A);
        c.fill(x + w - 1, y, x + w, y + h, 0xFFFF7A7A);
    }

    // скруглённый прямоугольник
    public static void round(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - d * d)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }
}
