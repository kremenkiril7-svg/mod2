package com.visuals;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.slf4j.LoggerFactory;
import java.util.*;

public class VisualsMod implements ClientModInitializer {
    static final boolean[] prevKey = new boolean[16];
    static boolean menuPrev = false;
    static final Set<Integer> done = new HashSet<>();

    @Override
    public void onInitializeClient() {
        LoggerFactory.getLogger("visuals").info("Visuals mod loaded!");
        Config.load();
        Sounds.register();
        Songs.register();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("visuals").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new VisualsScreen()));
                    return Command.SINGLE_SUCCESS;
                })));

        // HUD: остров-плеер, ESP-квадраты, инфо
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
            if (mc.currentScreen instanceof VisualsScreen) return;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            if (Config.island && Config.fpsMode < 2) Island.render(ctx, mc, sw, sh, -1, -1, false);
            Hud.plain(ctx, mc, sw, sh);
            Lyrics.render(ctx, mc, sw, sh);
            Esp.draw(ctx, mc, tc.getTickDelta(false));
            if (Cheats.info) Esp.info(ctx, mc);
        });

        // звук удара
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity && player == MinecraftClient.getInstance().player) Sounds.hit();
            return ActionResult.PASS;
        });

        // анти-отдача: после пакетов, до тика игрока
        ClientTickEvents.START_WORLD_TICK.register(world -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) Cheats.antiKbTick(mc.player);
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long handle = mc.getWindow().getHandle();

            boolean md = Config.keyMenu >= 0 && InputUtil.isKeyPressed(handle, Config.keyMenu);
            if (md && !menuPrev && mc.currentScreen == null) mc.setScreen(new VisualsScreen());
            menuPrev = md;

            for (int i = 0; i < prevKey.length; i++) {
                int k = Config.keys[i];
                boolean d = k >= 0 && InputUtil.isKeyPressed(handle, k);
                if (d && !prevKey[i] && mc.currentScreen == null) {
                    if (i < 13) Cheats.toggle(i);
                    else if (i == 13) Songs.prev();
                    else if (i == 14) Songs.toggle();
                    else Songs.next();
                }
                prevKey[i] = d;
            }

            Hud.tick();
            Songs.tick(mc);
            if (mc.player == null || mc.world == null) return;

            Cheats.tick(mc);
            Jump.tick(mc);
            Anims.tick(mc.world);

            // смерти мобов и игроков: анимация + звук
            Set<Integer> present = new HashSet<>();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
                if (le.isDead()) {
                    present.add(e.getId());
                    if (done.add(e.getId())) {
                        Vec3d pos = le.getPos();
                        boolean pl = le instanceof PlayerEntity;
                        Anims.play(pl ? Config.playerAnim : Config.mobAnim, pos);
                        Sounds.play(pl ? Config.playerSound : Config.mobSound, mc.world, pos);
                    }
                }
            }
            done.retainAll(present);
        });
    }
}
