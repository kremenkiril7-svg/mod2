package com.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class VisualsScreen extends Screen {
    static final int PW = 500, PH = 272, CW = 114;
    static final String[] TABS = {"Бой", "Мир", "Звуки", "Песни", "Приколно", "Одежда", "Профиль"};
    static final int T_FUN = 4, T_CLO = 5, T_PROF = 6;
    static final String[] INFO_NAMES = {"Броня", "Инвентарь", "Хотбар", "Прочность предметов", "Еда и здоровье", "Свободные слоты"};
    static final String[] LYR_POS = {"снизу", "сверху", "по центру"};
    static final String[] NAMES = {"Наводка+атака", "Супер 1.8", "Килаура", "Авто-выбор", "Анти-отдача",
            "Авто-блок", "Полёт", "Скорость", "Рентген", "Ночное зрение", "Игроки (ESP)", "Инфо", "Авто-подбор"};
    static final String[] SUBS = {"Плавно, с КД 1.9", "Мгновенно, спам", "Бьёт без наводки", "Булава / топор", "Не толкает",
            "Блок в руке", "Пробел / Shift", "Быстрый бег", "Только руды", "Видно в темноте", "Квадрат, хп, броня", "Инвентарь, прочность", "Предметы рядом"};
    static final String[] ANIMS = {"Нет", "Красная молния", "Золотой столб", "Огненный взрыв"};

    int tab = 0, px, py, waiting = -1, age = 0, dragging = -1;
    String nickMsg = "";
    TextFieldWidget nick;

    public VisualsScreen() { super(Text.literal("Читы")); }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
        nick = new TextFieldWidget(textRenderer, px + 10, py + 70, 200, 18, Text.literal(""));
        nick.setMaxLength(16);
        nick.setText(client.getSession().getUsername());
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void tick() { age++; }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fill(0, 0, width, height, 0xAA000000);
    }

    static String keyName(int k) {
        if (k < 0) return "—";
        String s = InputUtil.fromKeyCode(k, 0).getLocalizedText().getString();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }

    // ---------- геометрия ----------
    int[] trect(int i) {
        if (i < 5) return new int[]{px + 10, py + 54 + i * 36, 240, 32};
        int j = i - 5;
        return new int[]{px + 10 + (j / 4) * 245, py + 54 + (j % 4) * 36, 235, 32};
    }

    boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    boolean in(double mx, double my, int[] r) { return in(mx, my, r[0], r[1], r[2], r[3]); }

    // слайдеры: 0 радиус, 1 скорость, 2 радиус подбора, 3 размер прыжка, 4 размер инфо, 5 шляпа, 6 крылья, 7 размер текста песни
    int[] srect(int id) {
        return switch (id) {
            case 0 -> new int[]{px + 260, py + 54, 230, 16};
            case 1 -> new int[]{px + 260, py + 100, 230, 16};
            case 2 -> new int[]{px + 10, py + 204, 240, 16};
            case 3 -> new int[]{px + 256, py + 128, 234, 16};
            case 4 -> new int[]{px + 10, py + 186, 236, 16};
            case 5 -> new int[]{px + 260, py + 86, 230, 16};
            case 6 -> new int[]{px + 260, py + 154, 230, 16};
            default -> new int[]{px + 260, py + 192, 230, 16};
        };
    }

    int[] slidersFor(int t) {
        return switch (t) {
            case 0 -> new int[]{0, 1};
            case 1 -> new int[]{2};
            case 3 -> new int[]{7};
            case T_FUN -> new int[]{3, 4};
            case T_CLO -> new int[]{5, 6};
            default -> new int[]{};
        };
    }

    int[] cell(int x, int y, int w, int h, int cols, int idx, int gx, int gy) {
        return new int[]{x + (idx % cols) * (w + gx), y + (idx / cols) * (h + gy), w, h};
    }

    void rowToggle(DrawContext c, int x, int y, int w, int h, String name, boolean on) {
        Ui.slot(c, x, y, w, h, false);
        c.drawTextWithShadow(textRenderer, name, x + 5, y + (h - 8) / 2, 0xFFFFFFFF);
        switchBox(c, x + w - 36, y + (h - 14) / 2, on);
    }

    void swatches(DrawContext c, int x, int y, int sel) {
        for (int i = 0; i < Jump.COLORS.length; i++) {
            int sx = x + i * 34;
            int col = Jump.COLORS[i];
            if (col >= 0) c.fill(sx, y, sx + 30, y + 14, 0xFF000000 | col);
            else for (int k = 0; k < 30; k += 5) c.fill(sx + k, y, sx + k + 5, y + 14, 0xFF000000 | Jump.hsv(k / 30f));
            c.drawBorder(sx - 1, y - 1, 32, 16, i == sel ? 0xFFFFFFFF : 0xFF300000);
        }
    }

    int swatchAt(double mx, double my, int x, int y) {
        for (int i = 0; i < Jump.COLORS.length; i++) if (in(mx, my, x + i * 34, y, 30, 14)) return i;
        return -1;
    }

    // ---------- отрисовка ----------
    void toggleRow(DrawContext c, int i) {
        int[] r = trect(i);
        Ui.slot(c, r[0], r[1], r[2], r[3], false);
        c.drawTextWithShadow(textRenderer, NAMES[i], r[0] + 6, r[1] + 5, 0xFFFFFFFF);
        c.drawText(textRenderer, SUBS[i], r[0] + 6, r[1] + 17, 0xFFFFB0B0, false);
        int kx = r[0] + r[2] - 98;
        boolean wait = waiting == i;
        Ui.slot(c, kx, r[1] + 8, 54, 16, wait);
        c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[i]), kx + 27, r[1] + 12, 0xFFFFFFFF);
        switchBox(c, r[0] + r[2] - 40, r[1] + 9, Cheats.get(i));
    }

    void switchBox(DrawContext c, int x, int y, boolean on) {
        Ui.slot(c, x, y, 32, 14, on);
        int kn = on ? x + 18 : x + 2;
        c.fill(kn, y + 2, kn + 12, y + 12, 0xFFFFFFFF);
    }

    void slider(DrawContext c, int id, String label, double v, double min, double max) {
        int[] r = srect(id);
        c.drawTextWithShadow(textRenderer, label, r[0], r[1], 0xFFFFFFFF);
        Ui.slot(c, r[0], r[1] + 12, r[2], 8, false);
        int fw = (int) ((v - min) / (max - min) * (r[2] - 6));
        c.fill(r[0] + 2, r[1] + 14, r[0] + 2 + fw, r[1] + 18, 0xFFFF3A3A);
        c.fill(r[0] + fw, r[1] + 10, r[0] + fw + 6, r[1] + 22, 0xFFFFFFFF);
    }

    void card(DrawContext c, int x, int y, int w, int h, String name, boolean sel) {
        Ui.slot(c, x, y, w, h, sel);
        c.drawCenteredTextWithShadow(textRenderer, name, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }

    void btn(DrawContext c, int x, int y, int w, int h, String t, boolean active) { card(c, x, y, w, h, t, active); }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        Ui.panel(c, px, py, PW, PH);
        c.drawTextWithShadow(textRenderer, "Настройки", px + 10, py + 6, 0xFFFFFFFF);
        c.drawText(textRenderer, "Настрой игру под себя!", px + 10, py + 17, 0xFFFFC0C0, false);
        for (int i = 0; i < TABS.length; i++) {
            int x = px + 10 + i * 68;
            Ui.slot(c, x, py + 30, 66, 16, tab == i);
            c.drawCenteredTextWithShadow(textRenderer, TABS[i], x + 33, py + 34, 0xFFFFFFFF);
        }
        switch (tab) {
            case 0 -> renderCombat(c);
            case 1 -> renderWorld(c);
            case 2 -> renderSounds(c);
            case 3 -> renderSongs(c);
            case T_FUN -> renderFun(c);
            case T_CLO -> renderClothes(c);
            default -> renderProfile(c, mx, my, d);
        }
        if (Config.island && Config.fpsMode < 2) Island.render(c, client, width, height, mx, my, true);
    }

    void renderCombat(DrawContext c) {
        for (int i = 0; i < 5; i++) toggleRow(c, i);
        slider(c, 0, "Радиус удара: " + String.format("%.1f", Config.radius), Config.radius, 2.0, 6.0);
        slider(c, 1, "Скорость: " + Config.cps + " уд/сек", Config.cps, 1, 20);
        Ui.slot(c, px + 260, py + 134, 230, 24, false);
        c.drawTextWithShadow(textRenderer, "Килаура с перезарядкой 1.9", px + 266, py + 142, 0xFFFFFFFF);
        switchBox(c, px + 450, py + 139, Config.auraCd);
        c.drawText(textRenderer, "Дальше ~4 блоков сервер удар", px + 260, py + 170, 0xFFFFB0B0, false);
        c.drawText(textRenderer, "не засчитывает (радиус для наводки).", px + 260, py + 181, 0xFFFFB0B0, false);
    }

    void renderWorld(DrawContext c) {
        for (int i = 5; i < 13; i++) toggleRow(c, i);
        slider(c, 2, "Радиус авто-подбора: " + Config.pickupRadius + " бл.", Config.pickupRadius, 1, 16);
        c.drawText(textRenderer, "Подбор работает в одиночном мире", px + 260, py + 208, 0xFFFFB0B0, false);
    }

    void renderSounds(DrawContext c) {
        String[] labels = {"Звук смерти моба", "Звук смерти игрока", "Анимация смерти моба", "Анимация смерти игрока"};
        for (int g = 0; g < 4; g++) {
            c.drawTextWithShadow(textRenderer, labels[g], px + 10, py + 50 + g * 36, 0xFFFFFFFF);
            for (int i = 0; i < 4; i++) {
                String n = g < 2 ? Sounds.NAMES[i] : ANIMS[i];
                int cur = g == 0 ? Config.mobSound : g == 1 ? Config.playerSound : g == 2 ? Config.mobAnim : Config.playerAnim;
                int[] r = cell(px + 10, py + 61 + g * 36, CW, 20, 4, i, 6, 0);
                card(c, r[0], r[1], r[2], r[3], n, cur == i);
            }
        }
        c.drawTextWithShadow(textRenderer, "Звук удара", px + 10, py + 194, 0xFFFFFFFF);
        for (int i = 0; i < 8; i++) {
            int[] r = cell(px + 10, py + 205, CW, 20, 4, i, 6, 2);
            if (i < 7) card(c, r[0], r[1], r[2], r[3], Sounds.HIT_NAMES[i], Config.hitSound == i);
            else card(c, r[0], r[1], r[2], r[3], "Громкость: " + Sounds.HIT_VOL_NAMES[Config.hitVol], false);
        }
    }

    void renderSongs(DrawContext c) {
        for (int i = 0; i < 6; i++) {
            int x = px + 10, y = py + 54 + i * 30;
            if (i < Songs.TRACKS.size()) {
                Songs.Track t = Songs.TRACKS.get(i);
                boolean cur = Songs.playing && Songs.idx == i;
                Ui.slot(c, x, y, 240, 28, cur);
                c.drawTextWithShadow(textRenderer, (cur ? "▶ " : "♪ ") + t.name(), x + 6, y + 5, 0xFFFFFFFF);
                c.drawText(textRenderer, t.artist(), x + 6, y + 16, 0xFFFFB0B0, false);
            } else {
                Ui.slot(c, x, y, 240, 28, false);
                c.drawText(textRenderer, i < 3 ? "" : "— пусто (свои песни) —", x + 6, y + 10, 0xFFAA6060, false);
            }
        }
        c.drawText(textRenderer, "Свои песни: .ogg в visuals_songs", px + 10, py + 238, 0xFFFFFFFF, false);
        c.drawText(textRenderer, "Текст: файл .lrc с тем же именем", px + 10, py + 249, 0xFFFFFFFF, false);

        int rx = px + 260;
        rowToggle(c, rx, py + 54, 230, 26, "Анимация плеера", Config.island);
        rowToggle(c, rx, py + 84, 230, 26, "Текст песни на экране", Config.lyrics);

        String[] ic = {"|<", Songs.playing ? "||" : ">", ">|"};
        for (int i = 0; i < 3; i++) {
            btn(c, rx + i * 78, py + 114, 74, 22, ic[i], false);
            boolean wait = waiting == 13 + i;
            Ui.slot(c, rx + i * 78, py + 140, 74, 16, wait);
            c.drawCenteredTextWithShadow(textRenderer, wait ? "..." : keyName(Config.keys[13 + i]), rx + i * 78 + 37, py + 144, 0xFFFFFFFF);
        }
        c.drawText(textRenderer, "Клавиши: назад / пуск-стоп / вперёд", rx, py + 159, 0xFFFFB0B0, false);
        btn(c, rx, py + 170, 230, 18, "Текст: " + LYR_POS[Config.lyricsPos], false);
        slider(c, 7, "Размер текста: " + String.format("%.1f", Config.lyricsSize), Config.lyricsSize, 0.8, 2.5);
        btn(c, rx, py + 218, 230, 20, "Обновить свои песни", false);
        c.drawText(textRenderer, Songs.status, rx, py + 242, 0xFFFFE0E0, false);
        c.drawText(textRenderer, Lyrics.status, rx, py + 253, 0xFFFFE0E0, false);
    }

    void renderFun(DrawContext c) {
        int x0 = px + 10, x1 = px + 256;
        c.drawTextWithShadow(textRenderer, "Инфо-панель (кнопка «Инфо»)", x0, py + 52, 0xFFFFFFFF);
        boolean[] on = {Config.infoArmor, Config.infoInv, Config.infoHotbar, Config.infoDura, Config.infoFood, Config.infoSlots};
        for (int i = 0; i < 6; i++) rowToggle(c, x0, py + 62 + i * 17, 236, 16, INFO_NAMES[i], on[i]);
        for (int i = 0; i < 4; i++) {
            int[] r = cell(x0, py + 166, 56, 16, 4, i, 4, 0);
            card(c, r[0], r[1], r[2], r[3], Hud.CORNERS[i], Config.infoCorner == i);
        }
        slider(c, 4, "Размер панели: " + String.format("%.1f", Config.infoScale), Config.infoScale, 0.6, 1.2);
        c.drawTextWithShadow(textRenderer, "Показ FPS", x0, py + 212, 0xFFFFFFFF);
        for (int i = 0; i < 4; i++) {
            int[] r = cell(x0, py + 223, 56, 16, 4, i, 4, 0);
            card(c, r[0], r[1], r[2], r[3], Hud.FPS_MODES[i], Config.fpsMode == i);
        }
        btn(c, x0, py + 241, 236, 16, "Где: " + Hud.FPS_POS[Config.fpsPos], false);

        c.drawTextWithShadow(textRenderer, "Анимация прыжка", x1, py + 52, 0xFFFFFFFF);
        for (int i = 0; i < 6; i++) {
            int[] r = cell(x1, py + 62, 76, 16, 3, i, 3, 2);
            if (i < 5) card(c, r[0], r[1], r[2], r[3], Jump.STYLES[i], Config.jumpAnim == i);
            else card(c, r[0], r[1], r[2], r[3], "Приземл.: " + (Config.jumpLand ? "Да" : "Нет"), Config.jumpLand);
        }
        c.drawText(textRenderer, "Цвет", x1, py + 100, 0xFFFFB0B0, false);
        swatches(c, x1, py + 111, Config.jumpColor);
        slider(c, 3, "Размер: " + String.format("%.1f", Config.jumpSize), Config.jumpSize, 0.5, 2.0);

        c.drawTextWithShadow(textRenderer, "Оптимизация FPS", x1, py + 158, 0xFFFFFFFF);
        for (int i = 0; i < 4; i++) {
            int[] r = cell(x1, py + 169, 56, 16, 4, i, 3, 0);
            card(c, r[0], r[1], r[2], r[3], Opt.NAMES[i], Config.optLevel == i);
        }
        c.drawText(textRenderer, "Снижает дальность, тени и облака,", x1, py + 190, 0xFFFFB0B0, false);
        c.drawText(textRenderer, "быстрая графика. «Выкл» вернёт всё.", x1, py + 201, 0xFFFFB0B0, false);
        c.drawText(textRenderer, "Макс: ещё и меньше частиц.", x1, py + 212, 0xFFFFB0B0, false);
        c.drawText(textRenderer, "Сейчас: " + client.getCurrentFps() + " FPS", x1, py + 226, 0xFFFFE0E0, false);
    }

    void renderClothes(DrawContext c) {
        int x0 = px + 10;
        c.drawTextWithShadow(textRenderer, "Шляпа", x0, py + 52, 0xFFFFFFFF);
        for (int i = 0; i < 5; i++) {
            int[] r = cell(x0, py + 63, 92, 18, 5, i, 5, 0);
            card(c, r[0], r[1], r[2], r[3], Clothes.HATS[i], Config.hatType == i);
        }
        c.drawText(textRenderer, "Цвет шляпы", x0, py + 87, 0xFFFFB0B0, false);
        swatches(c, x0, py + 98, Config.hatColor);
        slider(c, 5, "Размер шляпы: " + String.format("%.1f", Config.hatScale), Config.hatScale, 0.6, 1.6);

        c.drawTextWithShadow(textRenderer, "Крылья", x0, py + 120, 0xFFFFFFFF);
        for (int i = 0; i < 4; i++) {
            int[] r = cell(x0, py + 131, 114, 18, 4, i, 6, 0);
            card(c, r[0], r[1], r[2], r[3], Clothes.WINGS[i], Config.wingType == i);
        }
        c.drawText(textRenderer, "Цвет крыльев", x0, py + 155, 0xFFFFB0B0, false);
        swatches(c, x0, py + 166, Config.wingColor);
        slider(c, 6, "Размер крыльев: " + String.format("%.1f", Config.wingScale), Config.wingScale, 0.6, 1.6);

        rowToggle(c, x0, py + 190, 236, 18, "Махать крыльями", Config.wingFlap);
        c.drawText(textRenderer, "Видно от 3-го лица: нажми F5.", x0, py + 216, 0xFFFFE0E0, false);
        c.drawText(textRenderer, "Цвет «Радуга» переливается.", x0, py + 227, 0xFFFFE0E0, false);
    }

    void renderProfile(DrawContext c, int mx, int my, float d) {
        c.drawTextWithShadow(textRenderer, "Ник в игре", px + 10, py + 56, 0xFFFFFFFF);
        nick.render(c, mx, my, d);
        btn(c, px + 220, py + 69, 120, 20, "Сменить ник", false);
        c.drawText(textRenderer, nickMsg, px + 10, py + 94, 0xFFFFE0E0, false);
        c.drawText(textRenderer, "Ник меняется сразу, без перезахода в лаунчер.", px + 10, py + 108, 0xFFFFB0B0, false);
        c.drawText(textRenderer, "Чтобы он применился в игре, перезайди в мир.", px + 10, py + 119, 0xFFFFB0B0, false);

        c.drawTextWithShadow(textRenderer, "Клавиша меню", px + 10, py + 148, 0xFFFFFFFF);
        boolean wm = waiting == 100;
        Ui.slot(c, px + 110, py + 144, 70, 16, wm);
        c.drawCenteredTextWithShadow(textRenderer, wm ? "..." : keyName(Config.keyMenu), px + 145, py + 148, 0xFFFFFFFF);
        c.drawText(textRenderer, "Нажми на кнопку клавиши и жми нужную. Esc — убрать.", px + 10, py + 168, 0xFFFFB0B0, false);
    }

    // ---------- ввод ----------
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (tab == T_PROF && nick.isFocused()) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { nickMsg = Nick.set(nick.getText().trim()); return true; }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { nick.setFocused(false); return true; }
            return nick.keyPressed(keyCode, scanCode, modifiers);
        }
        if (waiting != -1) {
            int val = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
            if (waiting == 100) { if (val != -1) Config.keyMenu = val; }
            else Config.keys[waiting] = val;
            waiting = -1;
            Config.save();
            return true;
        }
        if (keyCode == Config.keyMenu && age > 6) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (tab == T_PROF && nick.isFocused()) return nick.charTyped(chr, modifiers);
        return super.charTyped(chr, modifiers);
    }

    void setSlider(int id, double mx) {
        int[] r = srect(id);
        double f = MathHelper.clamp((mx - r[0] - 2) / (r[2] - 6), 0, 1);
        switch (id) {
            case 0 -> Config.radius = Math.round((2.0 + f * 4.0) * 10) / 10f;
            case 1 -> Config.cps = (int) Math.round(1 + f * 19);
            case 2 -> Config.pickupRadius = (int) Math.round(1 + f * 15);
            case 3 -> Config.jumpSize = Math.round((0.5 + f * 1.5) * 10) / 10f;
            case 4 -> Config.infoScale = Math.round((0.6 + f * 0.6) * 10) / 10f;
            case 5 -> Config.hatScale = Math.round((0.6 + f * 1.0) * 10) / 10f;
            case 6 -> Config.wingScale = Math.round((0.6 + f * 1.0) * 10) / 10f;
            default -> Config.lyricsSize = Math.round((0.8 + f * 1.7) * 10) / 10f;
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int b) {
        if (Config.island && Config.fpsMode < 2 && Island.click(width, height, mx, my)) return true;
        waiting = -1;
        for (int i = 0; i < TABS.length; i++)
            if (in(mx, my, px + 10 + i * 68, py + 30, 66, 16)) { tab = i; nick.setFocused(false); return true; }

        for (int id : slidersFor(tab)) {
            int[] r = srect(id);
            if (in(mx, my, r[0], r[1] + 8, r[2], 20)) { dragging = id; setSlider(id, mx); return true; }
        }

        if (tab == 0 || tab == 1) {
            int from = tab == 0 ? 0 : 5, to = tab == 0 ? 5 : 13;
            for (int i = from; i < to; i++) {
                int[] r = trect(i);
                if (in(mx, my, r[0] + r[2] - 98, r[1] + 8, 54, 16)) { waiting = i; return true; }
                if (in(mx, my, r)) { Cheats.toggle(i); return true; }
            }
            if (tab == 0 && in(mx, my, px + 260, py + 134, 230, 24)) { Config.auraCd = !Config.auraCd; Config.save(); return true; }
        } else if (tab == 2) {
            for (int g = 0; g < 4; g++)
                for (int i = 0; i < 4; i++) {
                    int[] r = cell(px + 10, py + 61 + g * 36, CW, 20, 4, i, 6, 0);
                    if (in(mx, my, r)) {
                        switch (g) {
                            case 0 -> { Config.mobSound = i; previewSound(i); }
                            case 1 -> { Config.playerSound = i; previewSound(i); }
                            case 2 -> { Config.mobAnim = i; previewAnim(i); }
                            default -> { Config.playerAnim = i; previewAnim(i); }
                        }
                        Config.save();
                        return true;
                    }
                }
            for (int i = 0; i < 8; i++) {
                int[] r = cell(px + 10, py + 205, CW, 20, 4, i, 6, 2);
                if (in(mx, my, r)) {
                    if (i < 7) Config.hitSound = i; else Config.hitVol = (Config.hitVol + 1) % 4;
                    Sounds.playHit(Config.hitSound, false);
                    Config.save();
                    return true;
                }
            }
        } else if (tab == 3) {
            for (int i = 0; i < Songs.TRACKS.size() && i < 6; i++)
                if (in(mx, my, px + 10, py + 54 + i * 30, 240, 28)) { Songs.play(i); return true; }
            int rx = px + 260;
            if (in(mx, my, rx, py + 54, 230, 26)) { Config.island = !Config.island; Config.save(); return true; }
            if (in(mx, my, rx, py + 84, 230, 26)) { Config.lyrics = !Config.lyrics; Config.save(); return true; }
            for (int i = 0; i < 3; i++) {
                if (in(mx, my, rx + i * 78, py + 114, 74, 22)) { if (i == 0) Songs.prev(); else if (i == 1) Songs.toggle(); else Songs.next(); return true; }
                if (in(mx, my, rx + i * 78, py + 140, 74, 16)) { waiting = 13 + i; return true; }
            }
            if (in(mx, my, rx, py + 170, 230, 18)) { Config.lyricsPos = (Config.lyricsPos + 1) % 3; Config.save(); return true; }
            if (in(mx, my, rx, py + 218, 230, 20)) { Songs.applyPack(client); return true; }
        } else if (tab == T_FUN) {
            int x0 = px + 10, x1 = px + 256;
            for (int i = 0; i < 6; i++)
                if (in(mx, my, x0, py + 62 + i * 17, 236, 16)) {
                    switch (i) {
                        case 0 -> Config.infoArmor = !Config.infoArmor;
                        case 1 -> Config.infoInv = !Config.infoInv;
                        case 2 -> Config.infoHotbar = !Config.infoHotbar;
                        case 3 -> Config.infoDura = !Config.infoDura;
                        case 4 -> Config.infoFood = !Config.infoFood;
                        default -> Config.infoSlots = !Config.infoSlots;
                    }
                    Config.save();
                    return true;
                }
            for (int i = 0; i < 4; i++)
                if (in(mx, my, cell(x0, py + 166, 56, 16, 4, i, 4, 0))) { Config.infoCorner = i; Config.save(); return true; }
            for (int i = 0; i < 4; i++)
                if (in(mx, my, cell(x0, py + 223, 56, 16, 4, i, 4, 0))) { Config.fpsMode = i; Config.save(); return true; }
            if (in(mx, my, x0, py + 241, 236, 16)) { Config.fpsPos = (Config.fpsPos + 1) % 5; Config.save(); return true; }
            for (int i = 0; i < 6; i++)
                if (in(mx, my, cell(x1, py + 62, 76, 16, 3, i, 3, 2))) {
                    if (i < 5) { Config.jumpAnim = i; previewJump(i); } else Config.jumpLand = !Config.jumpLand;
                    Config.save();
                    return true;
                }
            int sw = swatchAt(mx, my, x1, py + 111);
            if (sw >= 0) { Config.jumpColor = sw; Config.save(); if (Config.jumpAnim > 0) previewJump(Config.jumpAnim); return true; }
            for (int i = 0; i < 4; i++)
                if (in(mx, my, cell(x1, py + 169, 56, 16, 4, i, 3, 0))) { Opt.apply(client, i); return true; }
        } else if (tab == T_CLO) {
            int x0 = px + 10;
            for (int i = 0; i < 5; i++)
                if (in(mx, my, cell(x0, py + 63, 92, 18, 5, i, 5, 0))) { Config.hatType = i; Config.save(); return true; }
            for (int i = 0; i < 4; i++)
                if (in(mx, my, cell(x0, py + 131, 114, 18, 4, i, 6, 0))) { Config.wingType = i; Config.save(); return true; }
            int sh = swatchAt(mx, my, x0, py + 98);
            if (sh >= 0) { Config.hatColor = sh; Config.save(); return true; }
            int sw = swatchAt(mx, my, x0, py + 166);
            if (sw >= 0) { Config.wingColor = sw; Config.save(); return true; }
            if (in(mx, my, x0, py + 190, 236, 18)) { Config.wingFlap = !Config.wingFlap; Config.save(); return true; }
        } else {
            if (in(mx, my, px + 220, py + 69, 120, 20)) { nickMsg = Nick.set(nick.getText().trim()); return true; }
            if (in(mx, my, px + 110, py + 144, 70, 16)) { waiting = 100; return true; }
            boolean inside = in(mx, my, px + 10, py + 70, 200, 18);
            nick.setFocused(inside);
            if (inside) { nick.mouseClicked(mx, my, b); return true; }
        }
        return super.mouseClicked(mx, my, b);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
        if (dragging >= 0) { setSlider(dragging, mx); return true; }
        return super.mouseDragged(mx, my, b, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int b) {
        if (dragging >= 0) { dragging = -1; Config.save(); return true; }
        return super.mouseReleased(mx, my, b);
    }

    void previewSound(int i) {
        if (client.world != null && client.player != null) Sounds.play(i, client.world, client.player.getPos());
    }

    void previewAnim(int i) {
        if (client.player == null) return;
        Vec3d look = client.player.getRotationVec(1f);
        Anims.play(i, client.player.getPos().add(look.x * 5, 0, look.z * 5));
    }

    void previewJump(int i) {
        if (client.player == null || i <= 0) return;
        Vec3d look = client.player.getRotationVec(1f);
        Jump.play(i, client.player.getPos().add(look.x * 3, 0, look.z * 3));
    }
}
