package com.visuals.mixin;

import com.visuals.Clothes;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Одежда (шляпа, крылья): рисуем после отрисовки сущности. require = 0 -> если метод не найден, игра не падает.
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("TAIL"), require = 0)
    private void visuals$clothes(Entity entity, double x, double y, double z, float tickDelta, MatrixStack matrices,
                                 VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        Clothes.render(entity, x, y, z, tickDelta, matrices, consumers);
    }
}
