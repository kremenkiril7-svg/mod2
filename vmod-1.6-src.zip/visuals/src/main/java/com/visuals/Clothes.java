package com.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

// Шляпы и крылья для игрока (видны от 3-го лица, F5)
public class Clothes {
    public static final String[] HATS = {"Нет", "Китайская шляпа", "Нимб", "Цилиндр", "Корона"};
    public static final String[] WINGS = {"Нет", "Перья (ангел)", "Летучая мышь"};

    public static void render(WorldRenderContext ctx) {
        if (Config.hat == 0 && Config.wings == 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        Camera cam = ctx.camera();
        if (!cam.isThirdPerson()) return;
        if (p.isInvisible() || p.isSleeping() || p.isSpectator() || p.isFallFlying() || p.isSwimming()) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;

        float td = mc.getRenderTickCounter().getTickDelta(true);
        double x = MathHelper.lerp(td, p.prevX, p.getX());
        double y = MathHelper.lerp(td, p.prevY, p.getY());
        double z = MathHelper.lerp(td, p.prevZ, p.getZ());
        Vec3d c = cam.getPos();
        float yaw = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
        float time = mc.world.getTime() + td;
        float h = (float) p.getHeight();
        boolean sneak = p.isSneaking();

        ms.push();
        ms.translate(x - c.x, y - c.y, z - c.z);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        Draw.begin(vcp, ms.peek().getPositionMatrix());
        if (Config.hat > 0) hat(h, time);
        if (Config.wings > 0) wings(h, time, !p.isOnGround(), sneak);
        Draw.end();
        ms.pop();
    }

    // ---------- шляпы ----------
    static void hat(float h, float time) {
        float k = Config.hatSize / 100f;
        int col = Draw.color(Config.hatColor, time);
        int lite = Draw.light(col);
        switch (Config.hat) {
            case 1 -> { // китайская шляпа
                float r = 0.62f * k, ht = 0.34f * k, y = h + 0.02f;
                Draw.cone(y, r, ht, 40, col, 0.55f, 0.20f);
                Draw.cone(y + 0.005f, r * 0.55f, ht * 0.55f, 28, lite, 0.18f, 0.0f);
                Draw.ring(y, r - 0.03f, r + 0.03f * k, 48, lite, 0.95f, 0.95f);
                Draw.ring(y, r * 0.60f, r * 0.60f + 0.02f, 36, lite, 0.45f, 0.45f);
            }
            case 2 -> { // нимб
                float y = h + 0.32f * k + (float) Math.sin(time * 0.1f) * 0.03f;
                Draw.ring(y, 0.20f * k, 0.28f * k, 40, lite, 0.95f, 0.95f);
                Draw.ring(y, 0.14f * k, 0.36f * k, 40, col, 0.35f, 0.0f);
            }
            case 3 -> { // цилиндр
                float r = 0.27f * k, ht = 0.45f * k, y = h + 0.0f;
                Draw.wall(y, r, ht, 28, col, 0.75f, 0.55f, 0);
                Draw.disc(y + ht, r, 28, lite, 0.75f);
                Draw.ring(y, r, r + 0.2f * k, 36, col, 0.7f, 0.5f);
                Draw.wall(y + 0.07f * k, r + 0.002f, 0.08f * k, 28, 0xFFFFFF, 0.9f, 0.9f, 0);
            }
            default -> { // корона
                float r = 0.27f * k, ht = 0.12f * k, y = h + 0.0f;
                Draw.wall(y, r, ht, 24, col, 0.85f, 0.85f, 0);
                int n = 8;
                for (int i = 0; i < n; i++) {
                    double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n, am = (a0 + a1) / 2;
                    Draw.tri((float) Math.cos(a0) * r, y + ht, (float) Math.sin(a0) * r,
                            (float) Math.cos(a1) * r, y + ht, (float) Math.sin(a1) * r,
                            (float) Math.cos(am) * r, y + ht + 0.2f * k, (float) Math.sin(am) * r,
                            lite, 0.8f, 0.8f, 0.95f);
                }
            }
        }
    }

    // ---------- крылья ----------
    static final float[] LEN = {0.55f, 0.72f, 0.88f, 1.0f, 0.95f, 0.8f, 0.6f};
    static final float[] BAT_A = {18f, 48f, 78f, 104f};
    static final float[] BAT_L = {1.0f, 1.2f, 1.05f, 0.7f};

    static void wings(float h, float time, boolean air, boolean sneak) {
        float k = Config.wingSize / 100f;
        int col = Draw.color(Config.wingColor, time);
        float sp = Config.wingSpeed / 100f;
        float flap = (float) Math.sin(time * 0.32f * sp) * (air ? 24f : 7f);
        float ry = h - (sneak ? 0.62f : 0.48f);
        for (int s = -1; s <= 1; s += 2) {
            if (Config.wings == 1) feathers(s, 0.12f * s, ry, -0.17f, k, col, flap);
            else bat(s, 0.12f * s, ry, -0.17f, k, col, flap);
        }
    }

    // направление луча: ang = 0 вверх, 90 в сторону; немного назад
    static float[] dir(int s, float angDeg) {
        double a = Math.toRadians(angDeg);
        float dx = s * (float) Math.sin(a), dy = (float) Math.cos(a), dz = -0.35f;
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        return new float[]{dx / l, dy / l, dz / l};
    }

    static void feathers(int s, float rx, float ry, float rz, float k, int col, float flap) {
        for (int row = 0; row < 2; row++) {
            for (int i = 0; i < LEN.length; i++) {
                float t = i / (float) (LEN.length - 1);
                float ang = 12f + 98f * t + flap * (0.3f + 0.7f * t) + (row == 1 ? 6f : 0f);
                float len = LEN[i] * k * (row == 0 ? 1f : 0.62f);
                float[] d = dir(s, ang);
                float wx = d[1], wy = -d[0];
                float wl = (float) Math.sqrt(wx * wx + wy * wy);
                if (wl < 1e-4f) continue;
                wx /= wl; wy /= wl;
                float bw = 0.075f * k, tw = 0.04f * k;
                float bx = rx + d[0] * 0.04f, by = ry + d[1] * 0.04f, bz = rz + d[2] * 0.04f;
                float tx = rx + d[0] * len, ty = ry + d[1] * len, tz = rz + d[2] * len;
                float a0 = row == 0 ? 0.55f : 0.40f, a1 = row == 0 ? 0.14f : 0.10f;
                Draw.quad(bx - wx * bw, by - wy * bw, bz, bx + wx * bw, by + wy * bw, bz,
                        tx + wx * tw, ty + wy * tw, tz, tx - wx * tw, ty - wy * tw, tz,
                        col, a0, a0, a1, a1);
            }
        }
    }

    static void bat(int s, float rx, float ry, float rz, float k, int col, float flap) {
        int n = BAT_A.length;
        float[][] tip = new float[n][3];
        for (int j = 0; j < n; j++) {
            float[] d = dir(s, BAT_A[j] + flap * (0.4f + 0.2f * j));
            float l = BAT_L[j] * k;
            tip[j][0] = rx + d[0] * l;
            tip[j][1] = ry + d[1] * l;
            tip[j][2] = rz + d[2] * l;
        }
        int lite = Draw.light(col);
        for (int j = 0; j < n - 1; j++)
            Draw.tri(rx, ry, rz, tip[j][0], tip[j][1], tip[j][2], tip[j + 1][0], tip[j + 1][1], tip[j + 1][2], col, 0.45f, 0.25f, 0.25f);
        Draw.tri(rx, ry, rz, tip[n - 1][0], tip[n - 1][1], tip[n - 1][2], rx, ry - 0.5f * k, rz - 0.1f, col, 0.40f, 0.20f, 0.20f);
        for (int j = 0; j < n; j++) {
            float dx = tip[j][0] - rx, dy = tip[j][1] - ry;
            float l = (float) Math.sqrt(dx * dx + dy * dy);
            if (l < 1e-4f) continue;
            float wx = dy / l * 0.022f, wy = -dx / l * 0.022f;
            Draw.quad(rx - wx, ry - wy, rz, rx + wx, ry + wy, rz,
                    tip[j][0] + wx * 0.4f, tip[j][1] + wy * 0.4f, tip[j][2], tip[j][0] - wx * 0.4f, tip[j][1] - wy * 0.4f, tip[j][2],
                    lite, 0.9f, 0.9f, 0.7f, 0.7f);
        }
    }
}
