package com.visuals;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.MappingResolver;
import net.minecraft.client.MinecraftClient;
import java.lang.reflect.Field;

// Смена ника без перезапуска лаунчера
public class Nick {
    public static String set(String name) {
        try {
            if (name == null || name.length() < 1 || name.length() > 16) return "Ник: от 1 до 16 символов";
            Object s = MinecraftClient.getInstance().getSession();
            Class<?> sc = s.getClass();
            MappingResolver r = FabricLoader.getInstance().getMappingResolver();
            String named = r.unmapClassName("named", sc.getName());
            String fname = r.mapFieldName("named", named, "username", "Ljava/lang/String;");
            Field f = sc.getDeclaredField(fname);
            f.setAccessible(true);
            f.set(s, name);
            return "Ник: " + name + ". Перезайди в мир.";
        } catch (Throwable t) {
            return "Не удалось: " + t.getClass().getSimpleName();
        }
    }
}
