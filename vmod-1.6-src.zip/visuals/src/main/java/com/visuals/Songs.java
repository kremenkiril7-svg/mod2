package com.visuals;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public class Songs {
    public record Track(String name, String artist, int dur, SoundEvent ev) {}

    public static final List<Track> TRACKS = new ArrayList<>();
    static final String[] N = {"Он гениален", "Лбтд", "Я тебя лю"};
    static final String[] A = {"Wokawona", "Кис-Кис", "Dabro"};
    static final int[] D = {108, 176, 194};
    static final int MAX_OWN = 30;
    static SoundInstance cur;
    public static int idx = -1;
    public static boolean playing = false;
    static long startMs = 0;
    public static String status = "";

    public static Path songsDir() { return FabricLoader.getInstance().getGameDir().resolve("visuals_songs"); }

    public static void register() {
        for (int i = 0; i < 3; i++) {
            Identifier id = Identifier.of("visuals", "song" + (i + 1));
            SoundEvent ev = Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
            TRACKS.add(new Track(N[i], A[i], D[i], ev));
        }
        rescan();
    }

    static List<Path> oggFiles() {
        try {
            Files.createDirectories(songsDir());
            try (var st = Files.list(songsDir())) {
                return st.filter(p -> p.toString().toLowerCase().endsWith(".ogg")).sorted().limit(MAX_OWN).toList();
            }
        } catch (IOException e) { return List.of(); }
    }

    // длительность .ogg (Vorbis) в секундах: частота из заголовка, число сэмплов из последней страницы
    static int oggDuration(Path p) {
        try (RandomAccessFile f = new RandomAccessFile(p.toFile(), "r")) {
            long len = f.length();
            byte[] head = new byte[(int) Math.min(1024, len)];
            f.readFully(head);
            long rate = 0;
            for (int i = 0; i + 16 < head.length; i++) {
                if (head[i] == 1 && head[i + 1] == 'v' && head[i + 2] == 'o' && head[i + 3] == 'r'
                        && head[i + 4] == 'b' && head[i + 5] == 'i' && head[i + 6] == 's') {
                    rate = (head[i + 12] & 255L) | (head[i + 13] & 255L) << 8 | (head[i + 14] & 255L) << 16 | (head[i + 15] & 255L) << 24;
                    break;
                }
            }
            if (rate <= 0) return 0;
            int tail = (int) Math.min(70000, len);
            byte[] b = new byte[tail];
            f.seek(len - tail);
            f.readFully(b);
            for (int i = tail - 14; i >= 0; i--) {
                if (b[i] == 'O' && b[i + 1] == 'g' && b[i + 2] == 'g' && b[i + 3] == 'S') {
                    long gp = 0;
                    for (int k = 7; k >= 0; k--) gp = (gp << 8) | (b[i + 6 + k] & 255L);
                    return gp > 0 ? (int) (gp / rate) : 0;
                }
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    public static void rescan() {
        while (TRACKS.size() > 3) TRACKS.remove(TRACKS.size() - 1);
        List<Path> files = oggFiles();
        for (int i = 0; i < files.size(); i++) {
            String n = files.get(i).getFileName().toString();
            if (n.length() > 4) n = n.substring(0, n.length() - 4);
            TRACKS.add(new Track(n, "Свой файл", oggDuration(files.get(i)), SoundEvent.of(Identifier.of("visuals", "u" + (i + 1)))));
        }
    }

    public static Track current() { return idx >= 0 && idx < TRACKS.size() ? TRACKS.get(idx) : null; }

    public static long elapsedMs() { return playing ? System.currentTimeMillis() - startMs : 0; }

    public static int elapsedSec() { return (int) (elapsedMs() / 1000); }

    public static void play(int i) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (i < 0 || i >= TRACKS.size()) return;
        stopOnly();
        idx = i;
        cur = PositionedSoundInstance.master(TRACKS.get(i).ev(), 1.0f, 1.0f);
        mc.getSoundManager().play(cur);
        playing = true;
        startMs = System.currentTimeMillis();
        Lyrics.load(TRACKS.get(i), i);
        Island.expand();
    }

    static void stopOnly() {
        if (cur != null) MinecraftClient.getInstance().getSoundManager().stop(cur);
        cur = null;
        playing = false;
    }

    public static void stop() { stopOnly(); Island.expand(); }

    public static void toggle() {
        if (playing) stop(); else play(idx >= 0 ? idx : 0);
    }

    public static void next() { if (!TRACKS.isEmpty()) play(((idx < 0 ? -1 : idx) + 1) % TRACKS.size()); }

    public static void prev() { if (!TRACKS.isEmpty()) play(((idx <= 0 ? TRACKS.size() : idx) - 1) % TRACKS.size()); }

    public static void tick(MinecraftClient mc) {
        if (playing && cur != null && System.currentTimeMillis() - startMs > 1500
                && !mc.getSoundManager().isPlaying(cur)) next();
    }

    public static void openFolder() {
        try {
            Files.createDirectories(songsDir());
            Util.getOperatingSystem().open(songsDir().toFile());
        } catch (Throwable t) {
            status = "Открой вручную: " + songsDir();
        }
    }

    // файлы, перетащенные в окно меню: .ogg копируем, .lrc/.txt (тексты) тоже
    public static void addFiles(MinecraftClient mc, List<Path> paths) {
        int ogg = 0, other = 0, bad = 0;
        try {
            Files.createDirectories(songsDir());
            for (Path p : paths) {
                String n = p.getFileName().toString();
                String l = n.toLowerCase();
                if (l.endsWith(".ogg") || l.endsWith(".lrc") || l.endsWith(".txt")) {
                    Files.copy(p, songsDir().resolve(n), StandardCopyOption.REPLACE_EXISTING);
                    if (l.endsWith(".ogg")) ogg++; else other++;
                } else bad++;
            }
        } catch (Throwable t) { status = "Ошибка копирования"; return; }
        if (ogg > 0) applyPack(mc);
        else { rescan(); status = other > 0 ? "Тексты добавлены" : ""; }
        if (bad > 0) status = "Нужен .ogg (mp3/wav переведи в ogg, напр. в Audacity)";
    }

    // Собираем ресурспак из папки visuals_songs (.ogg) и перезагружаем ресурсы
    public static void applyPack(MinecraftClient mc) {
        try {
            List<Path> files = oggFiles();
            Path rp = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
            Files.createDirectories(rp);
            Path zip = rp.resolve("visuals_songs.zip");
            try (ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(zip))) {
                put(zo, "pack.mcmeta", "{\"pack\":{\"pack_format\":46,\"description\":\"Visuals songs\"}}");
                StringBuilder sj = new StringBuilder("{");
                for (int i = 0; i < files.size(); i++) {
                    String id = "u" + (i + 1);
                    zo.putNextEntry(new ZipEntry("assets/visuals/sounds/" + id + ".ogg"));
                    zo.write(Files.readAllBytes(files.get(i)));
                    zo.closeEntry();
                    sj.append(i > 0 ? "," : "").append("\"").append(id).append("\":{\"sounds\":[{\"name\":\"visuals:")
                            .append(id).append("\",\"stream\":true}]}");
                }
                sj.append("}");
                put(zo, "assets/visuals/sounds.json", sj.toString());
            }
            ResourcePackManager m = mc.getResourcePackManager();
            m.scanPacks();
            String pid = "file/visuals_songs.zip";
            if (!m.getEnabledIds().contains(pid)) m.enable(pid);
            if (!mc.options.resourcePacks.contains(pid)) { mc.options.resourcePacks.add(pid); mc.options.write(); }
            rescan();
            status = "Найдено песен: " + files.size() + ". Ресурсы перезагружаются...";
            mc.reloadResources();
        } catch (Throwable t) {
            status = "Ошибка: " + t.getClass().getSimpleName();
        }
    }

    static void put(ZipOutputStream zo, String name, String text) throws IOException {
        zo.putNextEntry(new ZipEntry(name));
        zo.write(text.getBytes(StandardCharsets.UTF_8));
        zo.closeEntry();
    }
}
