package com.visuals.mixin;

import com.visuals.Cheats;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Рентген: рисуем грани только у руд. require = 0 -> если метод не найден, игра не падает.
@Mixin(Block.class)
public class BlockMixin {
    @Inject(method = "shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Direction;)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private static void visuals$xrayNew(BlockState state, BlockState other, Direction side, CallbackInfoReturnable<Boolean> cir) {
        if (Cheats.xray) cir.setReturnValue(Cheats.isXrayBlock(state));
    }

    @Inject(method = "shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;Lnet/minecraft/util/math/BlockPos;)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private static void visuals$xrayOld(BlockState state, BlockView world, BlockPos pos, Direction side, BlockPos other, CallbackInfoReturnable<Boolean> cir) {
        if (Cheats.xray) cir.setReturnValue(Cheats.isXrayBlock(state));
    }
}
